<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "language_learning"; // Match this with phpMyAdmin

$conn = mysqli_connect($host, $user, $pass, $dbname);

if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
?>
